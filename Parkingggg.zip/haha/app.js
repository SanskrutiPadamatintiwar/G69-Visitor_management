var http = require('http');
var fs = require('fs');
var index = fs.readFileSync('index.html');

var SerialPort = require("serialport");
const parsers = SerialPort.parsers;
const parser = new parsers.Readline({
    delimiter: '\r\n'
});

var port = new SerialPort('COM5', {
    baudRate: 9600,
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false
});
port.pipe(parser);

var app = http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(index);
});

var io = require('socket.io')(app); // Updated to use the latest version syntax

io.on('connection', function (socket) {
    console.log('Client connected');
});

parser.on('data', function (data) {
    console.log(data);

    // Assuming data is numeric and represents detected value (0 or 100)
    let value = parseInt(data, 10);
    if (value === 100) {
        io.emit('data', 100); // Send 100 for detection
    } else if (value === 0) {
        io.emit('data', 0); // Send 0 for no detection
    }
});

app.listen(3000, () => {
    console.log('Server listening on port 3000');
});




