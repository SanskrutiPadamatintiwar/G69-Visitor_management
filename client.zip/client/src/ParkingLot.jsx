// ParkingLot.jsx
import React, { useEffect } from 'react';

const ParkingLot = () => {
  useEffect(() => {
    window.location.href = 'http://localhost:3000'; // Redirect to the server running on port 3000
  }, []);

  return (
    <div>
      <h1>Loading Parking Lot...</h1>
    </div>
  );
};

export default ParkingLot;
