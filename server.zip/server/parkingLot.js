// parkingLot.js
const express = require('express');
const http = require('http');
const path = require('path');
const SerialPort = require('serialport');
const { Readline } = SerialPort.parsers;
const socketIo = require('socket.io');

// Initialize Express App
const app = express();

// Create HTTP server
const server = http.createServer(app);

// Initialize Socket.io
const io = socketIo(server);

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Serial Port Configuration
const port = new SerialPort('COM5', {
  baudRate: 9600,
  dataBits: 8,
  parity: 'none',
  stopBits: 1,
  flowControl: false,
});

const parser = port.pipe(new Readline({ delimiter: '\r\n' }));

// Socket.io Connection
io.on('connection', (socket) => {
  console.log('Client connected');

  // Optionally, handle disconnection
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

// Handle data from Arduino
parser.on('data', (data) => {
  console.log('Data from Arduino:', data);

  const value = parseInt(data, 10);

  if (value === 100) {
    io.emit('parking-status', { occupied: true });
  } else if (value === 0) {
    io.emit('parking-status', { occupied: false });
  } else {
    console.warn('Unknown data received:', data);
  }
});

// Start Server
const PORT = 3000; // Choose an appropriate port
server.listen(PORT, () => {
  console.log(`Parking Lot server is running on http://localhost:${PORT}`);
});
